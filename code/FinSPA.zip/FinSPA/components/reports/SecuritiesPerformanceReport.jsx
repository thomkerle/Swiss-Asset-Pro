const React = require('react');
const { useState, useEffect, useRef } = React;

const getRequire = () => { try { return require; } catch (e) { return () => ({}); } };
const safeRequire = getRequire();

const Icon = safeRequire('../Icons.jsx') || (({name}) => <span>[{name}]</span>);
const DataEngine = safeRequire('../../data/DataEngine.jsx') || window.__FinSPAModules['data/DataEngine.jsx']?.exports || {};

const { getAssetValueAtDate = () => 0, generateMonthEnds = (s,e) => [s,e] } = DataEngine;

const ReportHeader = safeRequire('../ReportHeader.jsx') || (({title, subtitle}) => <div className="mb-8 border-b pb-4"><h2 className="text-3xl font-extrabold">{title}</h2><p>{subtitle}</p></div>);
const PdfExportEngine = safeRequire('../print/PdfExportEngine.jsx') || window.PdfExportEngine;
const UniversalChart = safeRequire('../../api/UniversalChart.jsx') || window.UniversalChart || (() => <div className="p-4 text-center">Chart fehlt</div>);

const SecuritiesPerformanceReport = ({ data, activeAssets, dateRange, isTreeVisible, setIsTreeVisible, fCur, t }) => {
  const chartRef = useRef(null);
  const activeChartEngine = (typeof window !== 'undefined' && window.__activeChartEngine) || data?.settings?.chartEngine || 'echarts';
  
  const [calcMethod, setCalcMethod] = useState('cumulative');

  const securitiesClasses = ['stock', 'fund', 'managed_fund'];
  const securitiesAssets = (activeAssets || []).filter(a => securitiesClasses.includes(a.assetClass));
  
  const stockAssets = securitiesAssets.filter(a => a.assetClass === 'stock');
  const fundAssets = securitiesAssets.filter(a => a.assetClass === 'fund');
  const managedAssets = securitiesAssets.filter(a => a.assetClass === 'managed_fund');

  if (securitiesAssets.length === 0) {
    return (
      <div className="max-w-6xl px-4 md:px-8 pb-12">
          <div className="bg-gray-50 dark:bg-slate-900 border-2 border-dashed border-gray-300 dark:border-slate-700 rounded-xl p-10 text-center text-gray-500">
          <Icon name="Info" size={32} className="mx-auto mb-3 opacity-50"/>
          <p>{t ? t('noSecuritiesData') || 'Keine Aktien, Fonds oder verwaltete Vermögen gefunden.' : 'Keine Aktien, Fonds oder verwaltete Vermögen gefunden.'}</p>
        </div>
      </div>
    );
  }

  let earliestDate = dateRange?.from;
  if (!earliestDate) {
      earliestDate = new Date().toISOString().split('T')[0];
      securitiesAssets.forEach(asset => {
          (asset.balances || []).forEach(b => { if (b.date < earliestDate) earliestDate = b.date; });
          (asset.bookings || []).forEach(b => { if (b.date < earliestDate) earliestDate = b.date; });
      });
  }

  const todayStr = dateRange?.to || new Date().toISOString().split('T')[0];

  const calculateCumulativeStats = (asset, targetDate) => {
      const investedInBase = DataEngine.getInvestedCapitalAtDate ? DataEngine.getInvestedCapitalAtDate(asset, targetDate, activeAssets) : 0;
      let totalDividendsCHF = 0;

      const sortedBookings = [...(asset.bookings || [])].sort((a,b) => new Date(a.date) - new Date(b.date));

      sortedBookings.forEach(bk => {
          if (bk.date <= targetDate) {
              const bkRate = parseFloat(String(bk.bookingExchangeRate || '1').replace(',', '.'));
              const assetRate = parseFloat(String(asset.exchangeRate || '1').replace(',', '.'));
              const rate = (bkRate !== 1 && bkRate !== 0) ? bkRate : assetRate;
              
              const rawType = String(bk.type || '').toLowerCase();
              const catStr = String(bk.subCategory || bk.category || '').toLowerCase();
              
              if (['dividende', 'ausschüttung'].includes(rawType) || catStr.includes('dividende')) {
                  totalDividendsCHF += Number(bk.amount || 0) * rate;
              }
          }
      });
      
      return { invested: investedInBase, yields: totalDividendsCHF, delta: investedInBase };
  };

  const calculatePeriodicStats = (asset, startDate, targetDate) => {
      const hasHistoryBeforeStart = (asset.balances || []).some(b => b.date <= startDate) || 
                                    (asset.bookings || []).some(b => b.date <= startDate);
      
      const actualStart = hasHistoryBeforeStart ? (getAssetValueAtDate(asset, startDate, activeAssets) || 0) : 0;
      
      const cumStart = calculateCumulativeStats(asset, startDate);
      const cumTarget = calculateCumulativeStats(asset, targetDate);

      return { 
          invested: actualStart + (cumTarget.invested - cumStart.invested), 
          yields: cumTarget.yields - cumStart.yields,
          delta: cumTarget.invested - cumStart.invested 
      };
  };

  let monthlyDates = generateMonthEnds(earliestDate, todayStr);
  if (!monthlyDates.includes(earliestDate)) monthlyDates.push(earliestDate);
  if (!monthlyDates.includes(todayStr)) monthlyDates.push(todayStr);
  
  monthlyDates.sort((a, b) => new Date(a) - new Date(b));
  monthlyDates = [...new Set(monthlyDates)];

  if (monthlyDates.length < 2) {
      const lastMonth = new Date(todayStr);
      lastMonth.setMonth(lastMonth.getMonth() - 1);
      const prev = lastMonth.toISOString().split('T')[0];
      monthlyDates.unshift(prev);
  }

  let monthlyDataPoints = monthlyDates.map(targetDate => {
      let stockInvested = 0, stockActual = 0, stockYields = 0, stockDelta = 0, stockPriceProfit = 0;
      let fundInvested = 0, fundActual = 0, fundYields = 0, fundDelta = 0, fundPriceProfit = 0;
      let managedInvested = 0, managedActual = 0, managedYields = 0, managedDelta = 0, managedPriceProfit = 0;

      stockAssets.forEach(asset => {
          const stats = calcMethod === 'cumulative' 
              ? calculateCumulativeStats(asset, targetDate)
              : calculatePeriodicStats(asset, earliestDate, targetDate);
          const act = getAssetValueAtDate(asset, targetDate, activeAssets);
          
          stockInvested += stats.invested;
          stockYields += stats.yields;
          stockDelta += stats.delta || 0;
          stockActual += act;
          stockPriceProfit += (act - stats.invested);
      });

      fundAssets.forEach(asset => {
          const stats = calcMethod === 'cumulative' 
              ? calculateCumulativeStats(asset, targetDate)
              : calculatePeriodicStats(asset, earliestDate, targetDate);
          const act = getAssetValueAtDate(asset, targetDate, activeAssets);
          
          fundInvested += stats.invested;
          fundYields += stats.yields;
          fundDelta += stats.delta || 0;
          fundActual += act;
          fundPriceProfit += (act - stats.invested);
      });

      managedAssets.forEach(asset => {
          const stats = calcMethod === 'cumulative' 
              ? calculateCumulativeStats(asset, targetDate)
              : calculatePeriodicStats(asset, earliestDate, targetDate);
          const act = getAssetValueAtDate(asset, targetDate, activeAssets);
          
          let pp = act - stats.invested;
          pp -= stats.yields;

          managedInvested += stats.invested;
          managedYields += stats.yields;
          managedDelta += stats.delta || 0;
          managedActual += act;
          managedPriceProfit += pp;
      });

      const totalInvested = stockInvested + fundInvested + managedInvested;
      const totalActual = stockActual + fundActual + managedActual;
      const totalYields = stockYields + fundYields + managedYields;
      const totalDelta = stockDelta + fundDelta + managedDelta;
      
      const priceProfit = stockPriceProfit + fundPriceProfit + managedPriceProfit;
      const profit = priceProfit + totalYields;

      return {
          dateStr: targetDate,
          stocks: { invested: stockInvested, actual: stockActual, yields: stockYields, delta: stockDelta },
          funds: { invested: fundInvested, actual: fundActual, yields: fundYields, delta: fundDelta },
          managed: { invested: managedInvested, actual: managedActual, yields: managedYields, delta: managedDelta },
          total: {
              invested: totalInvested,
              actual: totalActual,
              yields: totalYields,
              delta: totalDelta,
              priceProfit: priceProfit,
              priceRoi: totalInvested > 0 ? (priceProfit / totalInvested) * 100 : 0,
              profit: profit,
              roi: totalInvested > 0 ? (profit / totalInvested) * 100 : 0
          }
      };
  });

  const firstValidIndex = monthlyDataPoints.findIndex(d => d.total.invested > 0 || d.total.actual > 0 || d.total.yields !== 0);
  if (firstValidIndex > 0) {
      monthlyDataPoints = monthlyDataPoints.slice(firstValidIndex);
  }

  const latestData = monthlyDataPoints[monthlyDataPoints.length - 1]?.total || { invested: 0, actual: 0, delta: 0, priceProfit: 0, profit: 0, priceRoi: 0, roi: 0 };

  const currentStats = {
      stock: { invested: 0, actual: 0, yields: 0, delta: 0 },
      fund: { invested: 0, actual: 0, yields: 0, delta: 0 },
      managed_fund: { invested: 0, actual: 0, yields: 0, delta: 0 }
  };

  securitiesAssets.forEach(asset => {
      const stats = calcMethod === 'cumulative'
          ? calculateCumulativeStats(asset, todayStr)
          : calculatePeriodicStats(asset, earliestDate, todayStr);
      const act = getAssetValueAtDate(asset, todayStr, activeAssets);
      if (currentStats[asset.assetClass]) {
          currentStats[asset.assetClass].invested += stats.invested;
          currentStats[asset.assetClass].yields += stats.yields;
          currentStats[asset.assetClass].delta += stats.delta || 0;
          currentStats[asset.assetClass].actual += act;
      }
  });

  const repTitle = t ? t('repSecuritiesTitle') || "Aktien & Fonds Performance" : "Aktien & Fonds Performance";
  const repSub = t ? t('repSecuritiesSub') || "Rendite-Analyse des freien Markt-Portfolios (ohne Säule 3a)" : "Rendite-Analyse des freien Markt-Portfolios (ohne Säule 3a)";

  const loadHtml2Canvas = () => {
    return new Promise((resolve) => {
        if (window.html2canvas) return resolve(window.html2canvas);
        const script = document.createElement('script');
        script.src = "https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js";
        script.onload = () => resolve(window.html2canvas);
        document.head.appendChild(script);
    });
  };

  useEffect(() => {
    const buildReportData = async () => {
        const html2canvas = await loadHtml2Canvas();
        let chartsData = [];
        const isDark = document.documentElement.classList.contains('dark');
        const bgColor = isDark ? '#0f172a' : '#ffffff';

        const captureBlock = async (selector, titleFallback = '') => {
            const el = document.querySelector(selector);
            if (el) {
                await new Promise(resolve => setTimeout(resolve, 50));
                const canvas = await html2canvas(el, { 
                    scale: 2, 
                    backgroundColor: bgColor, 
                    useCORS: true, 
                    logging: false 
                });
                chartsData.push({ title: titleFallback, image: canvas.toDataURL('image/png', 1.0), width: 760 });
            }
        };

        await captureBlock('.dashboard-top-export-block', ''); 

        if (chartRef.current) {
            const containers = chartRef.current.querySelectorAll('.chart-export-block');
            for (let i = 0; i < containers.length; i++) {
                const titleFallback = containers[i].getAttribute('data-pdf-title') || '';
                const chartDiv = containers[i].querySelector('.universal-chart-wrapper > div') || containers[i].querySelector('div');
                
                if (chartDiv && window.echarts) {
                    const chartInstance = window.echarts.getInstanceByDom(chartDiv);
                    if (chartInstance) {
                        const imgData = chartInstance.getDataURL({ type: 'png', pixelRatio: 2.5, backgroundColor: bgColor });
                        chartsData.push({ title: titleFallback, image: imgData, fit: [360, 260] });
                        continue;
                    }
                }
                
                const canvas = await html2canvas(containers[i], { 
                    scale: 2, 
                    backgroundColor: bgColor, 
                    useCORS: true, 
                    logging: false,
                    ignoreElements: (element) => {
                        if (element.classList && element.classList.contains('echarts-tooltip')) return true;
                        if (element.tagName === 'DIV' && element.style && element.style.position === 'absolute' && element.style.top === '0px') return true;
                        return element.tagName === 'IFRAME' || element.tagName === 'NOSCRIPT';
                    }
                });
                chartsData.push({ title: titleFallback, image: canvas.toDataURL('image/png', 1.0), fit: [360, 260] }); 
            }
        }

        const tableHeaders = [
            t ? t('colMonth') || 'Monat' : 'Monat',
            t ? t('colStocksInv') || 'Aktien (Inv.)' : 'Aktien (Inv.)',
            t ? t('colStocksVal') || 'Aktien (Wert)' : 'Aktien (Wert)',
            t ? t('colFundsInv') || 'Fonds (Inv.)' : 'Fonds (Inv.)',
            t ? t('colFundsVal') || 'Fonds (Wert)' : 'Fonds (Wert)',
            t ? t('colManagedInv') || 'Verwaltet (Inv.)' : 'Verwaltet (Inv.)',
            t ? t('colManagedVal') || 'Verwaltet (Wert)' : 'Verwaltet (Wert)',
            t ? t('colTotalInv') || 'Total (Inv.)' : 'Total (Inv.)',
            t ? t('colTotalVal') || 'Total (Wert)' : 'Total (Wert)',
            t ? t('labelPriceProfit') || 'Kursgewinn' : 'Kursgewinn',
            t ? t('labelDividends') || 'Dividenden' : 'Dividenden',
            t ? t('labelTotalReturn') || 'Total Return' : 'Total Return'
        ];
        
        const tableBody = monthlyDataPoints.slice().reverse().map(d => {
            const dateObj = new Date(d.dateStr);
            const formattedDate = dateObj.toLocaleDateString('de-CH', { month: 'short', year: 'numeric' }); 
            return [
              formattedDate, 
              fCur(d.stocks.invested), fCur(d.stocks.actual), 
              fCur(d.funds.invested), fCur(d.funds.actual), 
              fCur(d.managed.invested), fCur(d.managed.actual), 
              fCur(d.total.invested), fCur(d.total.actual),
              `${d.total.priceProfit > 0 ? '+' : ''}${fCur(d.total.priceProfit)}`, 
              `+${fCur(d.total.yields)}`, 
              `${d.total.roi > 0 ? '+' : ''}${d.total.roi.toFixed(2)} %`
            ];
        });

        return { chartsData, tableHeaders, tableBody };
    };

    const handlePdfExport = async () => {
      try {
        if (!PdfExportEngine) return;
        const transCalcMethod = calcMethod === 'cumulative' ? (t ? t('calcCumulative') || 'Kumuliert' : 'Kumuliert') : (t ? t('calcPeriodic') || 'Zeitraum' : 'Zeitraum');
        const { chartsData, tableHeaders, tableBody } = await buildReportData();

        await PdfExportEngine.exportReport({
          title: `${repTitle} (${transCalcMethod})`,
          subtitle: repSub, 
          tableHeaders, 
          tableBody, 
          chartsData, 
          data
        });
      } catch (err) {
        console.error("[FinSPA] PDF Export Error im SecuritiesPerformanceReport:", err);
      }
    };

    const handleBatchExport = (e) => {
        const exportPromise = new Promise(async (resolve) => {
            try {
                const transCalcMethod = calcMethod === 'cumulative' ? (t ? t('calcCumulative') || 'Kumuliert' : 'Kumuliert') : (t ? t('calcPeriodic') || 'Zeitraum' : 'Zeitraum');
                const { chartsData, tableHeaders, tableBody } = await buildReportData();
                resolve({
                    order: 12, 
                    title: `${repTitle} (${transCalcMethod})`,
                    subtitle: repSub,
                    tableHeaders,
                    tableBody,
                    chartsData
                });
            } catch (err) {
                console.error("[FinSPA] Batch Export Error im SecuritiesPerformanceReport:", err);
                resolve(null);
            }
        });

        if (e.detail && typeof e.detail.registerPromise === 'function') {
            e.detail.registerPromise(exportPromise);
        }
    };

    window.addEventListener('triggerPdfExport', handlePdfExport);
    window.addEventListener('triggerPdfBatchExport', handleBatchExport);
    
    return () => {
        window.removeEventListener('triggerPdfExport', handlePdfExport);
        window.removeEventListener('triggerPdfBatchExport', handleBatchExport);
    };
  }, [monthlyDataPoints, fCur, t, repTitle, repSub, data, calcMethod]);

  // --- INTERPOLATION FÜR PROPORTIONALE X-ACHSE ---
  const interpolateTimeSeries = (points) => {
    if (!points || points.length < 2) return points;
    const result = [];
    
    const lerpObj = (o1, o2, ratio) => {
        const out = {};
        for (const key in o1) {
            if (typeof o1[key] === 'number' && typeof o2[key] === 'number') {
                out[key] = o1[key] + (o2[key] - o1[key]) * ratio;
            } else if (typeof o1[key] === 'object' && o1[key] !== null) {
                out[key] = lerpObj(o1[key], o2[key], ratio);
            } else {
                out[key] = o1[key];
            }
        }
        return out;
    };

    for (let i = 0; i < points.length - 1; i++) {
        const p1 = points[i];
        const p2 = points[i + 1];
        
        // Zwinge das Datum auf UTC, um DST-Sprünge zu vermeiden
        const t1 = new Date(p1.dateStr + 'T00:00:00Z').getTime();
        const t2 = new Date(p2.dateStr + 'T00:00:00Z').getTime();
        const days = Math.round((t2 - t1) / (1000 * 3600 * 24));
        
        result.push(p1);
        
        // Füge für jeden einzelnen Tag einen interpolierten Datenpunkt ein
        if (days > 1 && days < 1000) { 
            for (let d = 1; d < days; d++) {
                const ratio = d / days;
                const currentTime = t1 + d * 24 * 3600 * 1000;
                const interp = lerpObj(p1, p2, ratio);
                interp.dateStr = new Date(currentTime).toISOString().split('T')[0];
                interp.isInterpolated = true;
                result.push(interp);
            }
        }
    }
    result.push(points[points.length - 1]);
    return result;
  };

  const chartDataPoints = interpolateTimeSeries(monthlyDataPoints);

  const chartLabels = chartDataPoints.map(d => {
      const dateObj = new Date(d.dateStr);
      return `${('0'+dateObj.getDate()).slice(-2)}.${('0'+(dateObj.getMonth()+1)).slice(-2)}.${dateObj.getFullYear().toString().slice(-2)}`;
  });

  return (
    <div className="max-w-[1400px] px-4 md:px-8 pb-12 mx-auto">

      <div className="print-hide flex flex-col sm:flex-row justify-between items-start sm:items-center bg-slate-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-xl p-4 mb-8 gap-3 shadow-sm">
         <div className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider flex items-center gap-2">
            <Icon name="Activity" size={14} className="text-blue-500"/>
            {t ? t('methodDashMetrics') || 'Berechnungsmethode für Dashboard-Metriken:' : 'Berechnungsmethode für Dashboard-Metriken:'}
         </div>
         <div className="flex bg-gray-200/60 dark:bg-slate-800 p-1 rounded-lg border dark:border-slate-700 text-xs font-semibold self-stretch sm:self-auto justify-between sm:justify-start">
            <button 
                onClick={() => setCalcMethod('cumulative')}
                className={`px-4 py-1.5 rounded-md transition-all ${calcMethod === 'cumulative' ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-sm font-bold' : 'text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'}`}
            >
                {t ? t('methodCumLong') || 'Kumuliert (Gesamthistorie)' : 'Kumuliert (Gesamthistorie)'}
            </button>
            <button 
                onClick={() => setCalcMethod('periodic')}
                className={`px-4 py-1.5 rounded-md transition-all ${calcMethod === 'periodic' ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-sm font-bold' : 'text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'}`}
            >
                {t ? t('methodPerLong') || 'Perioden-isoliert (Zeitraum-Delta)' : 'Perioden-isoliert (Zeitraum-Delta)'}
            </button>
         </div>
      </div>

      <div className="dashboard-top-export-block w-full bg-white dark:bg-slate-950">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-8 p-1">
             <div className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 p-6 rounded-2xl shadow-sm overflow-hidden">
                <div className="text-gray-500 text-xs font-bold uppercase tracking-wider mb-2">
                    {calcMethod === 'cumulative' ? (t ? t('netInvestedTotal') || 'Netto Investiert (Total)' : 'Netto Investiert (Total)') : (t ? t('workingCapital') || 'Arbeitendes Kapital' : 'Arbeitendes Kapital')}
                </div>
                <div className="w-full">
                    <div className="font-black text-slate-900 dark:text-white flex flex-wrap items-baseline gap-x-2 gap-y-1 pb-1 text-xl md:text-2xl" title={fCur ? fCur(latestData.invested, 'CHF') : latestData.invested}>
                        <span>{fCur ? fCur(latestData.invested, 'CHF') : latestData.invested}</span>
                    </div>
                </div>
                {calcMethod === 'periodic' && (
                    <div className={`text-sm font-bold mt-1 flex items-center gap-1.5 ${latestData.delta >= 0 ? 'text-blue-600 dark:text-blue-400' : 'text-red-600'}`}>
                        <Icon name={latestData.delta >= 0 ? "TrendingUp" : "TrendingDown"} size={14} prefix="" /> 
                        {latestData.delta > 0 ? '+' : ''}{fCur ? fCur(latestData.delta, 'CHF') : latestData.delta} {t ? t('netInflow') || 'Netto-Zufluss' : 'Netto-Zufluss'}
                    </div>
                )}
                <div className="text-xs text-gray-400 mt-2 truncate">
                    {calcMethod === 'cumulative' 
                        ? (t ? t('descSecuritiesInvested') || 'Summe aller Käufe minus Verkäufe' : 'Summe aller Käufe minus Verkäufe') 
                        : `${t ? t('baseValuePlusInflows') || 'Basiswert' : 'Basiswert'} (${new Date(earliestDate).toLocaleDateString('de-CH')}) + ${t ? t('inflows') || 'Zuflüsse' : 'Zuflüsse'}`
                    }
                </div>
             </div>
             
             <div className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 p-6 rounded-2xl shadow-sm border-b-4 border-b-blue-500 overflow-hidden">
                <div className="text-gray-500 text-xs font-bold uppercase tracking-wider mb-2">{t ? t('marketValueEnd') || 'Marktwert per Ende' : 'Marktwert per Ende'}</div>
                <div className="w-full">
                    <div className="font-black text-blue-600 dark:text-blue-400 flex flex-wrap items-baseline gap-x-2 gap-y-1 pb-1 text-xl md:text-2xl" title={fCur ? fCur(latestData.actual, 'CHF') : latestData.actual}>
                        <span>{fCur ? fCur(latestData.actual, 'CHF') : latestData.actual}</span>
                    </div>
                </div>
                <div className="text-xs text-gray-400 mt-2">{t ? t('statusAsOf') || 'Stand per' : 'Stand per'} {new Date(todayStr).toLocaleDateString('de-CH')}</div>
             </div>
             
             <div className={`border p-6 rounded-2xl shadow-sm overflow-hidden ${latestData.priceProfit >= 0 ? 'bg-green-50 border-green-200 dark:bg-green-900/20' : 'bg-red-50 border-red-200 dark:bg-red-900/20'}`}>
                <div className={`text-xs font-bold uppercase tracking-wider mb-2 ${latestData.priceProfit >= 0 ? 'text-green-700 dark:text-green-400' : 'text-red-700 dark:text-green-400'}`}>
                    {t ? t('priceProfitInterval') || 'Kursgewinn im Intervall' : 'Kursgewinn im Intervall'}
                </div>
                <div className="w-full">
                    <div className={`flex flex-wrap items-baseline gap-x-2 gap-y-1 pb-1 ${latestData.priceProfit >= 0 ? 'text-green-700 dark:text-green-400' : 'text-red-700 dark:text-red-400'}`}>
                       <div className="font-black text-xl md:text-2xl" title={`${latestData.priceProfit > 0 ? '+' : ''}${fCur ? fCur(latestData.priceProfit, 'CHF') : latestData.priceProfit}`}>
                           {latestData.priceProfit > 0 ? '+' : ''}{fCur ? fCur(latestData.priceProfit, 'CHF') : latestData.priceProfit}
                       </div>
                       <span className="text-sm font-medium opacity-70 shrink-0">({latestData.priceRoi > 0 ? '+' : ''}{latestData.priceRoi.toFixed(2)}%)</span>
                    </div>
                </div>
             </div>
             
             <div className={`border p-6 rounded-2xl shadow-sm overflow-hidden ${latestData.profit >= 0 ? 'bg-indigo-50 border-indigo-200 dark:bg-indigo-900/20' : 'bg-orange-50 border-orange-200 dark:bg-orange-900/20'}`}>
                <div className={`text-xs font-bold uppercase tracking-wider mb-2 ${latestData.profit >= 0 ? 'text-indigo-700 dark:text-indigo-400' : 'text-orange-700 dark:text-orange-400'}`}>
                    {t ? t('labelTotalReturnDiv') || 'Total Return (inkl. Dividenden)' : 'Total Return (inkl. Dividenden)'}
                </div>
                <div className="w-full">
                    <div className={`flex flex-wrap items-baseline gap-x-2 gap-y-1 pb-1 ${latestData.profit >= 0 ? 'text-indigo-700 dark:text-indigo-400' : 'text-orange-700 dark:text-orange-400'}`}>
                       <div className="font-black text-xl md:text-2xl" title={`${latestData.profit > 0 ? '+' : ''}${fCur ? fCur(latestData.profit, 'CHF') : latestData.profit}`}>
                           {latestData.profit > 0 ? '+' : ''}{fCur ? fCur(latestData.profit, 'CHF') : latestData.profit}
                       </div>
                       <span className="text-sm font-medium opacity-70 shrink-0">({latestData.roi > 0 ? '+' : ''}{latestData.roi.toFixed(2)}%)</span>
                    </div>
                </div>
             </div>
          </div>

          <h3 className="font-bold text-lg mb-4 text-slate-800 dark:text-slate-200">{t ? t('labelBreakdownByAssetClass') || 'Aufschlüsselung nach Anlageklasse' : 'Aufschlüsselung nach Anlageklasse'}</h3>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            {securitiesClasses.map(cls => {
                const stats = currentStats[cls];
                if (stats.invested === 0 && stats.actual === 0 && stats.yields === 0) return null;
                
                let priceProfit = stats.actual - stats.invested;
                if (cls === 'managed_fund') priceProfit -= stats.yields; 

                const totalProfit = priceProfit + stats.yields;
                const roi = stats.invested > 0 ? (totalProfit / stats.invested) * 100 : 0;
                const isPos = totalProfit >= 0;
                
                const titleMap = { 
                    'stock': t ? t('acStock') || 'Aktien (Direktinvestments)' : 'Aktien (Direktinvestments)', 
                    'fund': t ? t('acFund') || 'Fonds / ETFs' : 'Fonds / ETFs',
                    'managed_fund': t ? t('acManagedFund') || 'Verwaltetes Vermögen' : 'Verwaltetes Vermögen'
                };
                const iconMap = { 'stock': 'TrendingUp', 'fund': 'PieChart', 'managed_fund': 'Activity' };

                return (
                    <div key={cls} className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm flex flex-col">
                        <div className="flex items-center gap-2 mb-4 text-slate-800 dark:text-slate-200 font-bold border-b border-gray-100 dark:border-slate-800 pb-3">
                            <div className="p-2 bg-blue-50 dark:bg-blue-900/30 rounded-lg text-blue-600 dark:text-blue-400">
                               <Icon name={iconMap[cls]} size={16} />
                            </div>
                            {titleMap[cls]}
                        </div>
                        <div className="space-y-3 text-sm flex-1">
                            <div className="flex justify-between items-center">
                                <span className="text-gray-500">
                                    {calcMethod === 'cumulative' 
                                        ? (t ? t('labelInvested') || 'Investiert:' : 'Investiert:') 
                                        : (t ? t('labelBasePlusInflows') || 'Basis + Zuflüsse:' : 'Basis + Zuflüsse:')}
                                </span>
                                <span className="font-mono">{fCur ? fCur(stats.invested, 'CHF') : stats.invested}</span>
                            </div>
                            {calcMethod === 'periodic' && (
                                <div className="flex justify-between items-center text-xs mt-1 border-b border-dashed border-gray-100 dark:border-slate-800 pb-1 mb-1">
                                    <span className="text-gray-400 pl-2">{t ? t('labelNetInflowPeriod') || '↳ Netto-Zufluss (Periode):' : '↳ Netto-Zufluss (Periode):'}</span>
                                    <span className={`font-mono font-bold ${stats.delta >= 0 ? 'text-blue-500' : 'text-red-500'}`}>
                                        {stats.delta > 0 ? '+' : ''}{fCur ? fCur(stats.delta, 'CHF') : stats.delta}
                                    </span>
                                </div>
                            )}
                            <div className="flex justify-between items-center">
                                <span className="text-gray-500">{t ? t('labelYieldsDiv') || 'Erträge (Dividenden):' : 'Erträge (Dividenden):'}</span>
                                <span className="font-mono text-indigo-500">+{fCur ? fCur(stats.yields, 'CHF') : stats.yields}</span>
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-gray-500">{t ? t('labelEndMarketValue') || 'End-Marktwert:' : 'End-Marktwert:'}</span>
                                <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{fCur ? fCur(stats.actual, 'CHF') : stats.actual}</span>
                            </div>
                        </div>
                        <div className={`mt-4 pt-3 border-t border-gray-100 dark:border-slate-800 flex justify-between font-bold ${isPos ? 'text-indigo-600 dark:text-indigo-400' : 'text-orange-600 dark:text-orange-400'}`}>
                            <span>{t ? t('labelResult') || 'Ergebnis:' : 'Ergebnis:'} {isPos ? '+' : ''}{fCur ? fCur(totalProfit, 'CHF') : totalProfit}</span>
                            <span>{isPos ? '+' : ''}{roi.toFixed(2)}%</span>
                        </div>
                    </div>
                );
            })}
          </div>
      </div>

      {monthlyDataPoints.length > 1 && (
         <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8" ref={chartRef}>
            
            <div 
               className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm chart-export-block"
               data-pdf-title={t ? t('devStocksPortfolio') || "Entwicklung Aktien Portfolio" : "Entwicklung Aktien Portfolio"}
               data-pdf-legend={JSON.stringify([
                   { name: calcMethod === 'cumulative' ? (t ? t('labelNetInvested') || 'Netto Investiert' : 'Netto Investiert') : (t ? t('workingCapital') || 'Arbeitendes Kapital' : 'Arbeitendes Kapital'), color: '#475569' },
                   { name: t ? t('labelMarketValue') || 'Marktwert' : 'Marktwert', color: '#10b981' },
                   { name: t ? t('labelTotalReturnYields') || 'Total Return (inkl. Div)' : 'Total Return (inkl. Div)', color: '#6366f1' }
               ])}
            >
                <h3 className="font-bold text-lg mb-6 flex items-center gap-2 text-slate-800 dark:text-slate-200">
                    <Icon name="TrendingUp" className="text-blue-500" /> {t ? t('devStocks') || "Entwicklung Aktien" : "Entwicklung Aktien"}
                </h3>
                <div style={{ width: '100%', height: '280px' }}>
                    <UniversalChart 
                        engine={activeChartEngine}
                        type="line"
                        xAxisType="time"
                        isTimeSeries={true}
                        showDataLabels={false}
                        labels={chartLabels}
                        datasets={[
                            {
                                name: calcMethod === 'cumulative' ? (t ? t('labelNetInvested') || 'Netto Investiert' : 'Netto Investiert') : (t ? t('workingCapital') || 'Arbeitendes Kapital' : 'Arbeitendes Kapital'),
                                data: chartDataPoints.map(d => d.stocks.invested),
                                backgroundColor: '#475569', 
                                valueFormatter: fCur,
                                label: { show: false }
                            },
                            {
                                name: t ? t('labelMarketValue') || 'Marktwert' : 'Marktwert',
                                data: chartDataPoints.map(d => d.stocks.actual),
                                backgroundColor: '#10b981', 
                                valueFormatter: fCur,
                                label: { show: false }
                            },
                            {
                                name: t ? t('labelTotalReturnYields') || 'Total Return (inkl. Div)' : 'Total Return (inkl. Div)',
                                data: chartDataPoints.map(d => d.stocks.actual + d.stocks.yields),
                                backgroundColor: '#6366f1',
                                valueFormatter: fCur,
                                label: { show: false }
                            }
                        ]} 
                        height="100%"
                    />
                </div>
            </div>

            <div 
               className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm chart-export-block"
               data-pdf-title={t ? t('devFundsPortfolio') || "Entwicklung Fonds / ETFs Portfolio" : "Entwicklung Fonds / ETFs Portfolio"}
               data-pdf-legend={JSON.stringify([
                   { name: calcMethod === 'cumulative' ? (t ? t('labelNetInvested') || 'Netto Investiert' : 'Netto Investiert') : (t ? t('workingCapital') || 'Arbeitendes Kapital' : 'Arbeitendes Kapital'), color: '#475569' },
                   { name: t ? t('labelMarketValue') || 'Marktwert' : 'Marktwert', color: '#10b981' },
                   { name: t ? t('labelTotalReturnYields') || 'Total Return (inkl. Div)' : 'Total Return (inkl. Div)', color: '#6366f1' }
               ])}
            >
                <h3 className="font-bold text-lg mb-6 flex items-center gap-2 text-slate-800 dark:text-slate-200">
                    <Icon name="PieChart" className="text-indigo-500" /> {t ? t('devFunds') || "Entwicklung Fonds / ETFs" : "Entwicklung Fonds / ETFs"}
                </h3>
                <div style={{ width: '100%', height: '280px' }}>
                    <UniversalChart 
                        engine={activeChartEngine}
                        type="line"
                        xAxisType="time"
                        isTimeSeries={true}
                        showDataLabels={false}
                        labels={chartLabels}
                        datasets={[
                            {
                                name: calcMethod === 'cumulative' ? (t ? t('labelNetInvested') || 'Netto Investiert' : 'Netto Investiert') : (t ? t('workingCapital') || 'Arbeitendes Kapital' : 'Arbeitendes Kapital'),
                                data: chartDataPoints.map(d => d.funds.invested),
                                backgroundColor: '#475569',
                                valueFormatter: fCur,
                                label: { show: false }
                            },
                            {
                                name: t ? t('labelMarketValue') || 'Marktwert' : 'Marktwert',
                                data: chartDataPoints.map(d => d.funds.actual),
                                backgroundColor: '#10b981',
                                valueFormatter: fCur,
                                label: { show: false }
                            },
                            {
                                name: t ? t('labelTotalReturnYields') || 'Total Return (inkl. Div)' : 'Total Return (inkl. Div)',
                                data: chartDataPoints.map(d => d.funds.actual + d.funds.yields),
                                backgroundColor: '#6366f1',
                                valueFormatter: fCur,
                                label: { show: false }
                            }
                        ]} 
                        height="100%"
                    />
                </div>
            </div>

            <div 
               className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm chart-export-block"
               data-pdf-title={t ? t('devManagedPortfolio') || "Entwicklung Verwaltetes Vermögen" : "Entwicklung Verwaltetes Vermögen"}
               data-pdf-legend={JSON.stringify([
                   { name: calcMethod === 'cumulative' ? (t ? t('labelNetInvested') || 'Netto Investiert' : 'Netto Investiert') : (t ? t('workingCapital') || 'Arbeitendes Kapital' : 'Arbeitendes Kapital'), color: '#475569' },
                   { name: t ? t('labelMarketValue') || 'Marktwert' : 'Marktwert', color: '#10b981' },
                   { name: t ? t('labelTotalReturnYields') || 'Total Return (inkl. Div)' : 'Total Return (inkl. Div)', color: '#6366f1' }
               ])}
            >
                <h3 className="font-bold text-lg mb-6 flex items-center gap-2 text-slate-800 dark:text-slate-200">
                    <Icon name="Activity" className="text-purple-500" /> {t ? t('devManaged') || "Entwicklung Verwaltetes Vermögen" : "Entwicklung Verwaltetes Vermögen"}
                </h3>
                <div style={{ width: '100%', height: '280px' }}>
                    <UniversalChart 
                        engine={activeChartEngine}
                        type="line"
                        xAxisType="time"
                        isTimeSeries={true}
                        showDataLabels={false}
                        labels={chartLabels}
                        datasets={[
                            {
                                name: calcMethod === 'cumulative' ? (t ? t('labelNetInvested') || 'Netto Investiert' : 'Netto Investiert') : (t ? t('workingCapital') || 'Arbeitendes Kapital' : 'Arbeitendes Kapital'),
                                data: chartDataPoints.map(d => d.managed.invested),
                                backgroundColor: '#475569',
                                valueFormatter: fCur,
                                label: { show: false }
                            },
                            {
                                name: t ? t('labelMarketValue') || 'Marktwert' : 'Marktwert',
                                data: chartDataPoints.map(d => d.managed.actual),
                                backgroundColor: '#10b981',
                                valueFormatter: fCur,
                                label: { show: false }
                            },
                            {
                                name: t ? t('labelTotalReturnYields') || 'Total Return (inkl. Div)' : 'Total Return (inkl. Div)',
                                data: chartDataPoints.map(d => d.managed.actual + d.managed.yields),
                                backgroundColor: '#6366f1',
                                valueFormatter: fCur,
                                label: { show: false }
                            }
                        ]} 
                        height="100%"
                    />
                </div>
            </div>

         </div>
      )}

      <div className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm mt-8">
         <div className="px-6 py-4 border-b border-gray-200 dark:border-slate-800 bg-gray-50 dark:bg-slate-800/50 font-bold text-gray-700 dark:text-gray-300">
             {t ? t('monthlyHistoryTotal') || 'Monatliche Historie & Renditen (Total)' : 'Monatliche Historie & Renditen (Total)'}
         </div>
         <div className="overflow-x-auto max-h-[500px] overflow-y-auto">
            <table className="w-full text-sm text-left relative">
               <thead className="text-xs text-gray-500 uppercase bg-white dark:bg-slate-900 border-b border-gray-200 dark:border-slate-800 sticky top-0 z-10 shadow-sm">
                  <tr className="border-b border-gray-100 dark:border-slate-800">
                     <th rowSpan="2" className="px-6 py-4 align-middle text-left bg-gray-50/50 dark:bg-slate-900/50">{t ? t('colMonthTarget') || 'Monat / Stichtag' : 'Monat / Stichtag'}</th>
                     <th colSpan="2" className="px-4 py-2 text-center text-blue-600 dark:text-blue-400 bg-blue-50/10 border-r border-gray-100 dark:border-slate-800">{t ? t('colStocks') || 'Aktien' : 'Aktien'}</th>
                     <th colSpan="2" className="px-4 py-2 text-center text-emerald-600 dark:text-emerald-400 bg-emerald-50/10 border-r border-gray-100 dark:border-slate-800">{t ? t('colFunds') || 'Fonds / ETFs' : 'Fonds / ETFs'}</th>
                     <th colSpan="2" className="px-4 py-2 text-center text-purple-600 dark:text-purple-400 bg-purple-50/10 border-r border-gray-100 dark:border-slate-800">{t ? t('acManagedFund') || 'Verwaltet' : 'Verwaltet'}</th>
                     <th colSpan="5" className="px-4 py-2 text-center text-slate-700 dark:text-slate-300 bg-slate-50/30">{t ? t('colOverallTotal') || 'Gesamtübersicht (Total)' : 'Gesamtübersicht (Total)'}</th>
                  </tr>
                  <tr>
                     <th className="px-4 py-3 text-right font-medium">{t ? t('labelInvestedHeader') || 'Investiert' : 'Investiert'}</th>
                     <th className="px-4 py-3 text-right font-medium border-r border-gray-100 dark:border-slate-800">{t ? t('labelMarketValueHeader') || 'Marktwert' : 'Marktwert'}</th>
                     
                     <th className="px-4 py-3 text-right font-medium">{t ? t('labelInvestedHeader') || 'Investiert' : 'Investiert'}</th>
                     <th className="px-4 py-3 text-right font-medium border-r border-gray-100 dark:border-slate-800">{t ? t('labelMarketValueHeader') || 'Marktwert' : 'Marktwert'}</th>
                     
                     <th className="px-4 py-3 text-right font-medium">{t ? t('labelInvestedHeader') || 'Investiert' : 'Investiert'}</th>
                     <th className="px-4 py-3 text-right font-medium border-r border-gray-100 dark:border-slate-800">{t ? t('labelMarketValueHeader') || 'Marktwert' : 'Marktwert'}</th>

                     <th className="px-4 py-3 text-right font-medium text-slate-600 dark:text-slate-400">{t ? t('labelInvestedHeader') || 'Investiert' : 'Investiert'}</th>
                     <th className="px-4 py-3 text-right font-bold text-slate-800 dark:text-slate-200">{t ? t('labelMarketValueHeader') || 'Marktwert' : 'Marktwert'}</th>
                     <th className="px-4 py-3 text-right font-medium">{t ? t('labelPriceProfit') || 'Kursgewinn' : 'Kursgewinn'}</th>
                     <th className="px-4 py-3 text-right text-blue-600 dark:text-blue-400 font-medium">{t ? t('labelDividends') || 'Dividenden' : 'Dividenden'}</th>
                     <th className="px-6 py-3 text-right text-indigo-600 dark:text-indigo-400 font-bold">{t ? t('labelTotalReturn') || 'Total Return' : 'Total Return'}</th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-gray-100 dark:divide-slate-800">
                  {monthlyDataPoints.slice().reverse().map((d, i) => {
                      const dateObj = new Date(d.dateStr);
                      const isCurrentMonth = d.dateStr === todayStr;
                      const monthLabel = dateObj.toLocaleDateString('de-CH', { month: 'long', year: 'numeric' });
                      const exactLabel = dateObj.toLocaleDateString('de-CH');
                      const isLastDay = new Date(dateObj.getFullYear(), dateObj.getMonth() + 1, 0).getDate() === dateObj.getDate();
                      const displayDate = isLastDay ? monthLabel : exactLabel;

                      return (
                          <tr key={i} className="hover:bg-gray-50 dark:hover:bg-slate-800/50">
                              <td className="px-6 py-3 font-bold text-slate-800 dark:text-slate-200 bg-gray-50/20 dark:bg-slate-900/10 whitespace-nowrap">
                                  {isCurrentMonth ? `${displayDate} ${t ? t('todayBracket') || '(Heute)' : '(Heute)'}` : displayDate}
                              </td>
                              <td className="px-4 py-3 text-right font-mono text-slate-400 dark:text-slate-500">{fCur ? fCur(d.stocks.invested, 'CHF') : d.stocks.invested}</td>
                              <td className="px-4 py-3 text-right font-mono text-slate-700 dark:text-slate-300 border-r border-gray-100 dark:border-slate-800">{fCur ? fCur(d.stocks.actual, 'CHF') : d.stocks.actual}</td>
                              
                              <td className="px-4 py-3 text-right font-mono text-slate-400 dark:text-slate-500">{fCur ? fCur(d.funds.invested, 'CHF') : d.funds.invested}</td>
                              <td className="px-4 py-3 text-right font-mono text-slate-700 dark:text-slate-300 border-r border-gray-100 dark:border-slate-800">{fCur ? fCur(d.funds.actual, 'CHF') : d.funds.actual}</td>
                              
                              <td className="px-4 py-3 text-right font-mono text-slate-400 dark:text-slate-500">{fCur ? fCur(d.managed.invested, 'CHF') : d.managed.invested}</td>
                              <td className="px-4 py-3 text-right font-mono text-slate-700 dark:text-slate-300 border-r border-gray-100 dark:border-slate-800">{fCur ? fCur(d.managed.actual, 'CHF') : d.managed.actual}</td>

                              <td className="px-4 py-3 text-right font-mono text-slate-500 dark:text-slate-400">{fCur ? fCur(d.total.invested, 'CHF') : d.total.invested}</td>
                              <td className="px-4 py-3 text-right font-mono font-bold text-slate-800 dark:text-slate-200">{fCur ? fCur(d.total.actual, 'CHF') : d.total.actual}</td>
                              <td className={`px-4 py-3 text-right font-mono whitespace-nowrap ${d.total.priceProfit >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                                 {d.total.priceProfit > 0 ? '+' : ''}{fCur ? fCur(d.total.priceProfit, 'CHF') : d.total.priceProfit} 
                                 <span className="text-[10px] ml-1">({d.total.priceRoi > 0 ? '+' : ''}{d.total.priceRoi.toFixed(1)}%)</span>
                              </td>
                              <td className="px-4 py-3 text-right font-mono text-blue-600 dark:text-blue-400 whitespace-nowrap">+{fCur ? fCur(d.total.yields, 'CHF') : d.total.yields}</td>
                              <td className={`px-6 py-3 text-right font-bold whitespace-nowrap ${d.total.profit >= 0 ? 'text-indigo-600 dark:text-indigo-400' : 'text-orange-600 dark:text-orange-400'}`}>
                                 {d.total.roi > 0 ? '+' : ''}{d.total.roi.toFixed(2)} %
                              </td>
                          </tr>
                      );
                  })}
               </tbody>
            </table>
         </div>
      </div>
    </div>
  );
};

module.exports = SecuritiesPerformanceReport;