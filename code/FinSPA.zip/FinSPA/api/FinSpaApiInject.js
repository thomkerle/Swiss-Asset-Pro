/**
 * @file FinSpaApiInject.js
 * @description Vollständige FinSPA_API inkl. Budget-Methoden und synchronisierter DataEngine Logik.
 */

const getFinSpaApiScript = () => `
<script>
// Global an window binden für das iFrame
window.FinSPA_API = {
    _getData: function() { 
        return window.finspaData || { banks: [], budget: {}, settings: {} }; 
    },

    // --- Helper (synchron mit DataEngine) ---
    _isSecurity: function(assetClass) {
        return ['stock', 'fund', 'crypto', 'pension_fund', 'pension_3a_fund'].includes(assetClass);
    },
    _parseRate: function(val) {
        return parseFloat(String(val || '1').replace(',', '.'));
    },
    _getTodayStr: function() {
        return new Date().toISOString().split('T')[0];
    },
    
    // Zentrale Klassifizierung von Buchungsflüssen (In/Out) - Synchron mit DataEngine
    _getBookingFlow: function(booking) {
        let amt = Number(booking.amount || 0);
        let isPositive = ['Einzahlung', 'Kauf', 'Wertanpassung', 'Dividende', 'Abzahlung'].includes(booking.type);
        
        // Sonderfall: Negative Wertanpassung wird als Abfluss/Wertminderung gewertet
        if (booking.type === 'Wertanpassung' && amt < 0) {
            isPositive = false;
            amt = Math.abs(amt);
        }

        return {
            isPositive: isPositive,
            amount: amt
        };
    },

    // --- Assets & Navigation ---
    getAllAssets: function() {
        const data = this._getData();
        const assets = [];
        function traverse(node, currentBank) {
            let bankName = currentBank;
            if (node.type === 'bank') bankName = node.name;
            if (node.type === 'asset') {
                assets.push({ ...node, bankName: bankName });
            }
            if (node.children) {
                node.children.forEach(child => traverse(child, bankName));
            }
        }
        (data.banks || []).forEach(bank => traverse(bank, 'Unbekannt'));
        return assets;
    },

    getLiquidAssets: function() {
        return this.getAllAssets().filter(a => a.isLiquid === true);
    },

    getAssetsByBank: function(bankName) {
        return this.getAllAssets().filter(a => a.bankName === bankName);
    },

    getAssetsByClass: function(assetClass) {
        return this.getAllAssets().filter(a => a.assetClass === assetClass);
    },

    // --- Neue dynamische Wertermittlung (aus DataEngine) ---
    getAssetSharesAtDate: function(asset, targetDate) {
        if (!this._isSecurity(asset.assetClass)) return 0;
        let sh = 0;
        if (asset.bookings) {
            asset.bookings.forEach(b => {
                if (b.date <= targetDate) {
                    if (['Kauf', 'Einzahlung', 'Dividende'].includes(b.type) && b.shares) sh += Number(b.shares);
                    if (['Verkauf', 'Auszahlung'].includes(b.type) && b.shares) sh -= Number(b.shares);
                }
            });
        }
        return sh > 0 ? sh : (Number(asset.shares) || 0);
    },

    getAssetPriceAtDate: function(asset, targetDate) {
        if (!this._isSecurity(asset.assetClass)) return 1;
        
        if (targetDate >= this._getTodayStr() && Number(asset.price) > 0) {
            return Number(asset.price);
        }
        
        let p = 0;
        if (asset.bookings) {
            const sorted = [...asset.bookings].sort((a,b) => new Date(a.date) - new Date(b.date));
            // KORREKTUR: Kein Filter mehr nach Typ, jeder gültige Preis zählt (analog DataEngine)
            const pastBookings = sorted.filter(b => b.date <= targetDate && Number(b.price) > 0);
            if (pastBookings.length > 0) {
                p = Number(pastBookings[pastBookings.length - 1].price);
            }
        }
        return p > 0 ? p : (Number(asset.price) || 0);
    },

    getAssetRawValueAtDate: function(asset, targetDate) {
        if (this._isSecurity(asset.assetClass)) {
            const sh = this.getAssetSharesAtDate(asset, targetDate);
            const pr = this.getAssetPriceAtDate(asset, targetDate);
            if (sh > 0 && pr > 0) return sh * pr;
        }

        let sortedBalances = [...(asset.balances || [])].sort((a,b) => new Date(a.date) - new Date(b.date));
        let applicableBalance = [...sortedBalances].reverse().find(b => b.date <= targetDate);
        let baseAmount = applicableBalance ? Number(applicableBalance.amount) : 0;
        let baseDate = applicableBalance ? applicableBalance.date : '1970-01-01';
        let netBookings = 0;

        if (asset.bookings) {
            asset.bookings.forEach(bk => {
                if (bk.date > baseDate && bk.date <= targetDate) {
                    // KORREKTUR: Nutzung der neuen zentralen getBookingFlow Logik
                    const flow = this._getBookingFlow(bk);
                    if (flow.isPositive) netBookings += flow.amount;
                    else netBookings -= flow.amount;
                }
            });
        }
        return baseAmount + netBookings;
    },

    getAssetValueAtDate: function(asset, targetDate, allAssets) {
        const rawValue = this.getAssetRawValueAtDate(asset, targetDate);
        
        if (!asset.currency || asset.currency === 'CHF') return rawValue;

        if (targetDate >= this._getTodayStr() && asset.exchangeRate) {
            return rawValue * this._parseRate(asset.exchangeRate);
        }

        let sortedBalances = [...(asset.balances || [])].sort((a,b) => new Date(a.date) - new Date(b.date));
        let applicableBalance = [...sortedBalances].reverse().find(b => b.date <= targetDate);
        let applicableRate = applicableBalance && applicableBalance.bookingExchangeRate ? applicableBalance.bookingExchangeRate : this._parseRate(asset.exchangeRate);
        let baseDate = applicableBalance ? applicableBalance.date : '1970-01-01';

        if (asset.bookings) {
            asset.bookings.forEach(bk => {
                if (bk.date > baseDate && bk.date <= targetDate) {
                    if (bk.bookingExchangeRate && bk.bookingExchangeRate !== 1) applicableRate = bk.bookingExchangeRate;
                }
            });
        }

        if (!applicableRate || applicableRate === 1) {
            let latestDate = '1970-01-01';
            const searchAssets = allAssets || this.getAllAssets();
            searchAssets.forEach(otherAsset => {
                if (otherAsset.currency === asset.currency) {
                    if (otherAsset.bookings) {
                        otherAsset.bookings.forEach(b => {
                            if (b.bookingExchangeRate && b.bookingExchangeRate !== 1 && b.date <= targetDate && b.date > latestDate) {
                                applicableRate = b.bookingExchangeRate;
                                latestDate = b.date;
                            }
                        });
                    }
                }
            });
        }

        return rawValue * this._parseRate(applicableRate || 1);
    },

    // --- Legacy Kompatibilität für die KI ---
    getLatestBalanceValue: function(asset) {
        return this.getAssetValueAtDate(asset, this._getTodayStr(), this.getAllAssets());
    },

    // --- Wealth Calculations ---
    getTotalWealth: function() {
        const today = this._getTodayStr();
        const allAssets = this.getAllAssets();
        return allAssets.reduce((sum, asset) => sum + this.getAssetValueAtDate(asset, today, allAssets), 0);
    },

    getTotalLiquidWealth: function() {
        const today = this._getTodayStr();
        const allAssets = this.getAllAssets();
        return this.getLiquidAssets().reduce((sum, asset) => sum + this.getAssetValueAtDate(asset, today, allAssets), 0);
    },

    getWealthDistributionByClass: function() {
        const data = this._getData();
        const allAssets = this.getAllAssets();
        const today = this._getTodayStr();
        const distribution = {};
        const classMap = {};
        
        if (data.settings && data.settings.assetClasses) {
            data.settings.assetClasses.forEach(ac => classMap[ac.id] = ac.name);
        }
        
        allAssets.forEach(asset => {
            const val = this.getAssetValueAtDate(asset, today, allAssets);
            const acName = classMap[asset.assetClass] || asset.assetClass || 'unknown';
            distribution[acName] = (distribution[acName] || 0) + val;
        });
        return distribution;
    },

    getWealthByBank: function() {
        const allAssets = this.getAllAssets();
        const today = this._getTodayStr();
        const bankTotals = {};
        
        allAssets.forEach(asset => {
            const bName = asset.bankName || 'Unbekannt';
            const val = this.getAssetValueAtDate(asset, today, allAssets);
            bankTotals[bName] = (bankTotals[bName] || 0) + val;
        });
        
        return Object.keys(bankTotals).map(name => ({
            bankName: name,
            totalValue: bankTotals[name]
        }));
    },

    // --- Bookings & Transaction Logic ---
    getAllBookings: function() {
        return this.getAllAssets().flatMap(asset => 
            (asset.bookings || []).map(booking => ({
                ...booking,
                assetName: asset.name,
                bankName: asset.bankName,
                assetClass: asset.assetClass
            }))
        );
    },

    getTotalFeesPaid: function() {
        return this.getAllBookings()
            .filter(b => b.type === 'Gebühr')
            .reduce((sum, b) => sum + (b.amount * (b.bookingExchangeRate || 1)), 0);
    },

    getTotalDividendsReceived: function() {
        return this.getAllBookings()
            .filter(b => b.type === 'Einzahlung' && b.subCategory === 'Dividenden')
            .reduce((sum, b) => sum + (b.amount * (b.bookingExchangeRate || 1)), 0);
    },

    getMonthlyCashflowHistory: function() {
        const bookings = this.getAllBookings();
        const cashflowMap = {};
        bookings.forEach(b => {
            if (!b.date) return;
            const month = b.date.substring(0, 7); 
            if (!cashflowMap[month]) cashflowMap[month] = { month: month, income: 0, expenses: 0, net: 0 };
            const amount = b.amount * (b.bookingExchangeRate || 1);
            if (['Einzahlung', 'Dividende', 'Verkauf'].includes(b.type)) cashflowMap[month].income += amount;
            else if (['Auszahlung', 'Gebühr', 'Kauf', 'Zinszahlung', 'Abzahlung'].includes(b.type)) cashflowMap[month].expenses += amount;
        });
        return Object.keys(cashflowMap).sort().map(m => {
            cashflowMap[m].net = cashflowMap[m].income - cashflowMap[m].expenses;
            return cashflowMap[m];
        });
    },

    // --- Budget API ---
    _normalizeToMonthly: function(items) {
        if (!items || !Array.isArray(items)) return 0;
        return items.reduce((sum, item) => {
            const amount = parseFloat(item.amount) || 0;
            return item.frequency === 'yearly' ? sum + (amount / 12) : sum + amount;
        }, 0);
    },

    getMonthlyIncome: function() {
        return this._normalizeToMonthly(this._getData().budget?.incomeSources);
    },

    getMonthlyFixedCosts: function() {
        const data = this._getData();
        return this._normalizeToMonthly(data.budget?.expenses) + this._normalizeToMonthly(data.budget?.subscriptions);
    },

    getBudgetOverview: function() {
        const income = this.getMonthlyIncome();
        const costs = this.getMonthlyFixedCosts();
        return {
            income: income,
            costs: costs,
            disposable: income - costs,
            savingsRate: income > 0 ? ((income - costs) / income) * 100 : 0
        };
    },

    getExpensesByCategory: function(categoryType) {
        const data = this._getData();
        const allItems = [...(data.budget?.expenses || []), ...(data.budget?.subscriptions || [])];
        return this._normalizeToMonthly(allItems.filter(i => i.ruleCategory === categoryType));
    },

    getFreeMonthlyBuffer: function() {
        return this.getMonthlyIncome() - this.getMonthlyFixedCosts();
    },

    getSavingsRate: function() {
        return this.getBudgetOverview().savingsRate;
    },

    getFireProgress: function() {
        const data = this._getData();
        const currentWealth = this.getTotalWealth();
        const targetWealth = data.goals?.fire?.target || 0;
        return {
            current: currentWealth,
            target: targetWealth,
            percentage: targetWealth > 0 ? Math.min((currentWealth / targetWealth) * 100, 100) : 0
        };
    },

    // --- PDF Export ---
    PDF: {
      exportDashboard: async function(config) {
            if (!window.PdfExportEngine) {
                alert("PDF-Engine ist noch nicht geladen oder nicht verfügbar.");
                return;
            }

            let chartsBase64 = [];
            const canvases = document.querySelectorAll('canvas');
            
            canvases.forEach(canvas => {
                const tempCtx = canvas.getContext('2d');
                const origComposite = tempCtx.globalCompositeOperation;
                tempCtx.globalCompositeOperation = 'destination-over';
                tempCtx.fillStyle = '#ffffff';
                tempCtx.fillRect(0, 0, canvas.width, canvas.height);
                chartsBase64.push(canvas.toDataURL('image/png', 1.0));
                tempCtx.globalCompositeOperation = origComposite;
            });

            await window.PdfExportEngine.exportReport({
                title: config.title || 'Dashboard Export',
                subtitle: config.subtitle || '',
                tableHeaders: config.tables?.[0]?.headers || [],
                tableBody: config.tables?.[0]?.rows || [],
                chartsBase64: chartsBase64,
        data: window.FinSPA_API._getData()
            });
        }
    }
};

const FinSPA_API = window.FinSPA_API;
</script>
`;

module.exports = { getFinSpaApiScript };